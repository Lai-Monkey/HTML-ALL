# dynamic
My first dynamic webpage
![Untitled](https://user-images.githubusercontent.com/75737923/225074928-435e69fb-7c66-4743-b188-94c5aa2aa216.jpg)
![Untitled1](https://user-images.githubusercontent.com/75737923/225074947-beca9cf8-29af-4edc-bee5-914968df181d.jpg)
![Untitled2](https://user-images.githubusercontent.com/75737923/225074955-61bf5743-ce6c-4ee9-a880-8594ff281d31.jpg)
![Untitled3](https://user-images.githubusercontent.com/75737923/225074963-f3f56e38-97b4-46ab-9aca-9688af2752e7.jpg)
![Untitled4](https://user-images.githubusercontent.com/75737923/225074970-bb74ce92-0513-4682-95e6-7ef6d7e52c8e.jpg)
